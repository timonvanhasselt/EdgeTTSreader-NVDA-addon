"""Edge TTS version information."""

__version__ = "6.1.11"
__version_info__ = tuple(int(num) for num in __version__.split("."))
